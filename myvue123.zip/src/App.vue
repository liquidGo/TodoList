<template>
  <div>
     <h3>App组件</h3>
     <button @click="show=true">打开对话框</button>
       <my-child :show="show" >
         <!--准备要分发到子组件的DOM结构-->
         <p slot="one">父组件，one</p>
         <p slot="two">父组件，two</p>
       </my-child>
  </div>
</template>

<script>
import MyChild from "@/MyChild";
export default {
  name:"App",
  components: {MyChild},
  data(){
    return {
      show:false
    }
  }
}
</script>

<style scoped>
.hide{
  display: none;
}
</style>